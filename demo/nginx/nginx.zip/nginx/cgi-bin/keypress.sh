#!/bin/bash

echo "HTTP/1.0 200 OK"
echo "Content-type: text/plain"
echo ""
../uinput-inject --keycode ${QUERY_STRING}
echo $?