#!/bin/bash

echo "HTTP/1.0 200 OK"
echo "Content-type: image/png"
echo ""
if ! ../screensht -
then
	cat "../html/TechnicalDifficulties.png"
fi
